Create zip file of the directory

```shell
cd chrome-extension
zip -r bookmarks.dev.chrome.extension.zip -r *
```
